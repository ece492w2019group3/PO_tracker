/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * RealTimeFilter_terminate.c
 *
 * Code generation for function 'RealTimeFilter_terminate'
 *
 */

/* Include files */
#include "RealTimeFilter.h"
#include "RealTimeFilter_terminate.h"

/* Function Definitions */
void RealTimeFilter_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (RealTimeFilter_terminate.c) */

/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * kal_tool_terminate.c
 *
 * Code generation for function 'kal_tool_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kal_tool.h"
#include "kal_tool_terminate.h"

/* Function Definitions */
void kal_tool_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (kal_tool_terminate.c) */

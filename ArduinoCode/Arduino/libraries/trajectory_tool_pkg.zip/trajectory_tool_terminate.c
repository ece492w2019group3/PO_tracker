/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: trajectory_tool_terminate.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 30-Mar-2019 15:04:56
 */

/* Include Files */
#include "trajectory_tool.h"
#include "trajectory_tool_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void trajectory_tool_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for trajectory_tool_terminate.c
 *
 * [EOF]
 */

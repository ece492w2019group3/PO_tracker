/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * asin.h
 *
 * Code generation for function 'asin'
 *
 */

#ifndef ASIN_H
#define ASIN_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "kal_tool_types.h"

/* Function Declarations */
extern void b_asin(double x[1600]);

#endif

/* End of code generation (asin.h) */

/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * imufiltercg.h
 *
 * Code generation for function 'imufiltercg'
 *
 */

#ifndef IMUFILTERCG_H
#define IMUFILTERCG_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "kal_tool_types.h"

/* Function Declarations */
extern c_fusion_internal_coder_imufilt *imufiltercg_imufiltercg
  (c_fusion_internal_coder_imufilt *obj);

#endif

/* End of code generation (imufiltercg.h) */

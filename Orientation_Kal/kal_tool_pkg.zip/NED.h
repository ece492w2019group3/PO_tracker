/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * NED.h
 *
 * Code generation for function 'NED'
 *
 */

#ifndef NED_H
#define NED_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "kal_tool_types.h"

/* Function Declarations */
extern void NED_ecompass(const double a[3], const double m[3], double R[9]);

#endif

/* End of code generation (NED.h) */

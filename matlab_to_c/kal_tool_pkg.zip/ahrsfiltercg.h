/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: ahrsfiltercg.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 01-Mar-2019 15:09:29
 */

#ifndef AHRSFILTERCG_H
#define AHRSFILTERCG_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "kal_tool_types.h"

/* Function Declarations */
extern c_fusion_internal_coder_ahrsfil *ahrsfiltercg_ahrsfiltercg
  (c_fusion_internal_coder_ahrsfil *obj);

#endif

/*
 * File trailer for ahrsfiltercg.h
 *
 * [EOF]
 */
